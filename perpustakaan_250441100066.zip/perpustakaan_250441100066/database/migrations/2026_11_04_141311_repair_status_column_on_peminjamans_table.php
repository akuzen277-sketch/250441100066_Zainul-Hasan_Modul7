<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasColumn('peminjamans', 'status')) {
            Schema::table('peminjamans', function (Blueprint $table) {
                $table->string('status')->default('menunggu');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('peminjamans', 'status')) {
            Schema::table('peminjamans', function (Blueprint $table) {
                $table->dropColumn('status');
            });
        }
    }
};