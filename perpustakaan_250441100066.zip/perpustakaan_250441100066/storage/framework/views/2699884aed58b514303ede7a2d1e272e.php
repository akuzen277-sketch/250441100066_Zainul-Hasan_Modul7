<?php $__env->startSection('content'); ?>
<!-- Panggil file CSS eksternal dari public/css/buku.css -->
<link rel="stylesheet" href="<?php echo e(asset('css/buku.css')); ?>">

<script>
    window.bukuPermissions = {
        create: <?php echo json_encode(auth()->user()->can('kelola-buku'), 15, 512) ?>,
        edit: <?php echo json_encode(auth()->user()->can('kelola-buku'), 15, 512) ?>,
        delete: <?php echo json_encode(auth()->user()->can('kelola-buku'), 15, 512) ?>
    };
</script>

<h2>Kelola Data Buku (Konsumsi REST API)</h2>

<div id="alert-container"></div>

<!-- Formulir tambah dan ubah buku hanya tersedia bagi admin dan petugas. -->
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola-buku')): ?>
    <div class="form-card">
        <h3 id="form-title">Tambah Buku Baru</h3>
        <form id="buku-form">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="buku_id">
            
            <div class="form-group">
                <label class="form-label">Kategori ID:</label>
                <input type="number" id="kategori_id" class="form-input" required>
            </div>
            <div class="form-group">
                <label class="form-label">Judul Buku:</label>
                <input type="text" id="judul" class="form-input-wide" required>
            </div>
            <div class="form-group">
                <label class="form-label">Penulis:</label>
                <input type="text" id="penulis" class="form-input-wide" required>
            </div>
            <div class="form-group">
                <label class="form-label">Tahun Terbit:</label>
                <input type="number" id="tahun_terbit" class="form-input" required>
            </div>

            <button type="submit" id="btn-submit" class="btn btn-submit">Simpan</button>
            <button type="button" id="btn-cancel" onclick="resetForm()" class="btn btn-cancel">Batal</button>
        </form>
    </div>

    <template id="buku-delete-form-template">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn-delete">Hapus</button>
        </form>
    </template>

    <template id="buku-edit-button-template">
        <button type="button" class="btn-edit">Ubah</button>
    </template>
<?php endif; ?>

<!-- Tabel Data Buku -->
<table class="table-buku">
    <thead>
        <tr>
            <th>Kategori</th>
            <th>Judul</th>
            <th>Penulis</th>
            <th>Tahun Terbit</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody id="buku-table-body">
        <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($book->kategori->nama ?? '-'); ?></td>
                <td><?php echo e($book->judul); ?></td>
                <td><?php echo e($book->penulis); ?></td>
                <td><?php echo e($book->tahun_terbit); ?></td>
                <td>-</td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" align="center">Tidak ada data buku.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<!-- Panggil file JS eksternal dari public/js/buku.js -->
<script src="<?php echo e(asset('js/buku.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\perpustakaan_250441100066\resources\views/buku/index.blade.php ENDPATH**/ ?>