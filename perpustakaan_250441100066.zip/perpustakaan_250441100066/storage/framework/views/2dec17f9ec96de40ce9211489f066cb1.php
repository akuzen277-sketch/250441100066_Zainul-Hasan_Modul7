
<?php $__env->startSection('content'); ?>
    <?php if($buku): ?>
        <h2>Detail Buku</h2>
        <?php if (isset($component)) { $__componentOriginal4043f1b18f0274362ee9613e82bd7ae0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4043f1b18f0274362ee9613e82bd7ae0 = $attributes; } ?>
<?php $component = App\View\Components\BookCard::resolve(['judul' => $buku->judul,'penulis' => $buku->penulis,'tahunTerbit' => $buku->tahun_terbit,'kategori' => $buku->kategori?->nama] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('book-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BookCard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <a href="<?php echo e(route('buku.index')); ?>">Kembali ke Daftar Buku</a>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4043f1b18f0274362ee9613e82bd7ae0)): ?>
<?php $attributes = $__attributesOriginal4043f1b18f0274362ee9613e82bd7ae0; ?>
<?php unset($__attributesOriginal4043f1b18f0274362ee9613e82bd7ae0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4043f1b18f0274362ee9613e82bd7ae0)): ?>
<?php $component = $__componentOriginal4043f1b18f0274362ee9613e82bd7ae0; ?>
<?php unset($__componentOriginal4043f1b18f0274362ee9613e82bd7ae0); ?>
<?php endif; ?>
    <?php else: ?>
        <h2>Data buku tidak ditemukan.</h2>
        <a href="<?php echo e(route('buku.index')); ?>">Kembali</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\perpustakaan_250441100066\resources\views/buku/show.blade.php ENDPATH**/ ?>