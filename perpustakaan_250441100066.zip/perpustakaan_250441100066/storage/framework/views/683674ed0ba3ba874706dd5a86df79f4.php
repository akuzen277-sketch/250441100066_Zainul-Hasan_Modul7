
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Perpustakaan Digital'); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>

    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/buku.css')); ?>">
</head>

<?php
    $user = auth()->user();

    $theme = 'theme-siswa';
    $roleName = 'Siswa';

    if ($user && $user->hasRole('admin')) {
        $theme = 'theme-admin';
        $roleName = 'Admin';
    } elseif ($user && $user->hasRole('petugas')) {
        $theme = 'theme-petugas';
        $roleName = 'Petugas';
    }
?>

<body>
<div class="dashboard-wrapper <?php echo e($theme); ?>">

    <!-- SIDEBAR -->
    <aside class="sidebar">

        <div class="sidebar-brand">
            <div class="sidebar-logo">📚</div>
            <div>
                <h3>Perpustakaan</h3>
                <span>Digital Library System</span>
            </div>
        </div>

        <p class="menu-label">MENU UTAMA</p>

        <ul class="sidebar-menu">
            <li>
                <a href="<?php echo e(route('home')); ?>"
                   class="<?php echo e(request()->routeIs('home', 'dashboard') ? 'active' : ''); ?>">
                    <span>🏠</span>
                    <span>Dashboard</span>
                </a>
            </li>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view buku')): ?>
            <li>
                <a href="<?php echo e(route('buku.index')); ?>"
                   class="<?php echo e(request()->routeIs('buku.*') ? 'active' : ''); ?>">
                    <span>📖</span>
                    <span>Data Buku</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['kelola peminjaman', 'melihat status peminjaman sendiri', 'melihat riwayat peminjaman sendiri', 'mengajukan peminjaman buku'])): ?>
            <li>
                <a href="<?php echo e(route('peminjaman.index')); ?>"
                   class="<?php echo e(request()->routeIs('peminjaman.*') ? 'active' : ''); ?>">
                    <span>📋</span>
                    <span>Peminjaman</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['kelola data pengguna', 'kelola role pengguna'])): ?>
            <li>
                <a href="<?php echo e(route('users.index')); ?>"
                   class="<?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>">
                    <span>👥</span>
                    <span>Pengguna</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lihat laporan perpustakaan')): ?>
            <li>
                <a href="<?php echo e(route('laporan.index')); ?>"
                   class="<?php echo e(request()->routeIs('laporan.*') ? 'active' : ''); ?>">
                    <span>📊</span>
                    <span>Laporan</span>
                </a>
            </li>
            <?php endif; ?>
        </ul>

        <div class="sidebar-bottom">
            <div class="sidebar-user">
                <div class="user-avatar">
                    <?php echo e(strtoupper(substr($user->name ?? 'U', 0, 1))); ?>

                </div>
                <div>
                    <strong><?php echo e($user->name ?? 'Pengguna'); ?></strong>
                    <span><?php echo e($roleName); ?></span>
                </div>
            </div>

            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn-logout">
                    ↪ Keluar
                </button>
            </form>
        </div>

    </aside>

    <!-- KONTEN UTAMA -->
    <main class="main-content">

        <header class="topbar">
            <div>
                <h2>Sistem Informasi Perpustakaan</h2>
                <p>Selamat datang di perpustakaan digital</p>
            </div>

            <div class="user-profile">
                <div class="user-avatar">
                    <?php echo e(strtoupper(substr($user->name ?? 'U', 0, 1))); ?>

                </div>
                <div class="user-info">
                    <strong><?php echo e($user->name ?? 'Pengguna'); ?></strong>
                    <span class="role-badge"><?php echo e($roleName); ?></span>
                </div>
            </div>
        </header>

        <section class="page-content">
            <?php echo $__env->yieldContent('content'); ?>
        </section>

        <footer class="main-footer">
            &copy; 2026 Sistem Informasi Perpustakaan
        </footer>

    </main>

</div>
</body>
</html>
<?php /**PATH D:\laragon\www\perpustakaan_250441100066\resources\views/layouts/main.blade.php ENDPATH**/ ?>