


<?php $__env->startSection('title', 'Dashboard Petugas'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <h1>Dashboard Petugas 👋</h1>
    <p>Selamat datang, <?php echo e(auth()->user()->name); ?>. Kelola koleksi buku perpustakaan.</p>
</div>

<div class="stats-grid">

    <div class="stat-card">
        <div class="stat-icon">📚</div>
        <p>Pengelolaan</p>
        <h2>Data Buku</h2>
    </div>

    <div class="stat-card">
        <div class="stat-icon">➕</div>
        <p>Fitur</p>
        <h2>Tambah Buku</h2>
    </div>

    <div class="stat-card">
        <div class="stat-icon">✏️</div>
        <p>Fitur</p>
        <h2>Ubah Buku</h2>
    </div>

</div>

<div class="content-card">
    <h3>Panel Petugas</h3>
    <p>Anda dapat melihat, menambahkan, dan mengubah data buku sesuai hak akses.</p>

    <br>

    <a href="<?php echo e(route('buku.index')); ?>" class="btn-primary">
        Kelola Data Buku →
    </a>
</div>
<div class="content-card">
    <div class="stat-icon">
        📚
    </div>

    <h3>Pengajuan Peminjaman</h3>

    <p>
        Lihat dan kelola pengajuan peminjaman buku
        yang diajukan oleh siswa.
    </p>

    <a href="<?php echo e(route('peminjaman.index')); ?>" class="btn-primary">
        Lihat Pengajuan
    </a>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\perpustakaan_250441100066\resources\views/dashboard/petugas.blade.php ENDPATH**/ ?>