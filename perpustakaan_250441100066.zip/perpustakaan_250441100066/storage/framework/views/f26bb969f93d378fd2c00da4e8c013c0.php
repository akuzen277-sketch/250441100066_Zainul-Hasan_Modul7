<div class="card">
    <h3><?php echo e($judul); ?></h3>
    <p><strong>Penulis:</strong> <?php echo e($penulis); ?></p>
    <p><strong>Tahun Terbit:</strong> <?php echo e($tahunTerbit); ?></p>
    <?php if(isset($kategori)): ?>
        <p><strong>Kategori:</strong> <?php echo e($kategori); ?></p>
    <?php endif; ?>
    <div><?php echo e($slot); ?></div>
</div><?php /**PATH D:\laragon\www\perpustakaan_250441100066\resources\views/components/book-card.blade.php ENDPATH**/ ?>