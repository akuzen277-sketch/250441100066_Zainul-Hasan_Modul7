<?php $__env->startSection('title', 'Dashboard Siswa'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <h1>Dashboard Siswa 👋</h1>
    <p>Selamat datang, <?php echo e(auth()->user()->name); ?>. Temukan koleksi buku perpustakaan.</p>
</div>

<div class="stats-grid">

    <div class="stat-card">
        <div class="stat-icon">📖</div>
        <p>Menu Utama</p>
        <h2>Koleksi Buku</h2>
    </div>

    <div class="stat-card">
        <div class="stat-icon">🔎</div>
        <p>Fitur</p>
        <h2>Lihat Buku</h2>
    </div>
    

</div>

<div class="content-card">
    <h3>Selamat Datang di Perpustakaan Digital</h3>
    <p>Silakan melihat koleksi buku yang tersedia di perpustakaan.</p>

    <br>

    <a href="<?php echo e(route('buku.index')); ?>" class="btn-primary">
        Lihat Koleksi Buku →
    </a>
</div>


<div class="content-card">
    <h3>Menu Peminjaman Buku 📚</h3>
    <p>Ajukan peminjaman dan pantau status buku yang kamu pinjam.</p>

    <br>

    <a href="<?php echo e(route('peminjaman.create')); ?>" class="btn-primary">
        Ajukan Peminjaman →
    </a>
</div>

<div class="content-card">
    <h3>Lihat Peminjaman Buku 📚</h3>
    <p>Pantau status buku yang kamu pinjam.</p>
    
    <br>

    <a href="<?php echo e(route('peminjaman.index')); ?>" class="btn-primary">
        Lihat Peminjaman →
    </a>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\perpustakaan_250441100066\resources\views/dashboard/siswa.blade.php ENDPATH**/ ?>