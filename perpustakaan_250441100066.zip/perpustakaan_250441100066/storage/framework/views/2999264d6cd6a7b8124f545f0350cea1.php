

<?php $__env->startSection('title', 'Detail Peminjaman'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-card">
        <h1>Detail Peminjaman</h1>

        <dl>
            <dt>Peminjam</dt>
            <dd><?php echo e($peminjaman->anggota->nama ?? '-'); ?></dd>

            <dt>Buku</dt>
            <dd><?php echo e($peminjaman->buku->judul ?? '-'); ?></dd>

            <dt>Tanggal pinjam</dt>
            <dd><?php echo e($peminjaman->tanggal_pinjam); ?></dd>

            <dt>Tanggal kembali</dt>
            <dd><?php echo e($peminjaman->tanggal_kembali ?? 'Belum ditentukan'); ?></dd>

            <dt>Status</dt>
            <dd><?php echo e(ucfirst($peminjaman->status)); ?></dd>
        </dl>

        <a href="<?php echo e(route('peminjaman.index')); ?>">Kembali ke daftar peminjaman</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\perpustakaan_250441100066\resources\views/peminjaman/show.blade.php ENDPATH**/ ?>