<?php $__env->startSection('title', 'Manajemen Pengguna'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <h1>Manajemen Pengguna 👥</h1>
    <p>Kelola data akun pengguna perpustakaan dan atur pembagian hak akses (role).</p>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">👥</div>
        <p>Total Pengguna</p>
        <h2><?php echo e($users->count()); ?></h2>
    </div>

    <div class="stat-card">
        <div class="stat-icon">👑</div>
        <p>Admin</p>
        <h2><?php echo e($users->filter(fn($u) => $u->hasRole('admin'))->count()); ?></h2>
    </div>

    <div class="stat-card">
        <div class="stat-icon">👔</div>
        <p>Petugas</p>
        <h2><?php echo e($users->filter(fn($u) => $u->hasRole('petugas'))->count()); ?></h2>
    </div>

    <div class="stat-card">
        <div class="stat-icon">🎓</div>
        <p>Siswa</p>
        <h2><?php echo e($users->filter(fn($u) => $u->hasRole('siswa') || $u->hasRole('anggota'))->count()); ?></h2>
    </div>
</div>

<div class="content-card">

    <h3>Daftar Akun Pengguna</h3>
    <p>Daftar seluruh pengguna yang terdaftar pada sistem perpustakaan.</p>

    <?php if(session('success')): ?>
        <div class="alert alert-success" style="background:#dcfce7;color:#15803d;padding:12px;border-radius:6px;margin-bottom:16px;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger" style="background:#fee2e2;color:#991b1b;padding:12px;border-radius:6px;margin-bottom:16px;">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger" style="background:#fee2e2;color:#991b1b;padding:12px;border-radius:6px;margin-bottom:16px;">
            <ul style="margin:0;padding-left:20px;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-peminjaman align-middle">
            <thead>
                <tr>
                    <th>NO</th>
                    <th>NAMA</th>
                    <th>EMAIL</th>
                    <th>DATA ANGGOTA</th>
                    <th>ROLE SAAT INI</th>
                    <th>ATUR ROLE</th>
                    <th>AKSI</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td>
                            <strong><?php echo e($item->name); ?></strong>
                            <?php if($item->id === auth()->id()): ?>
                                <span style="font-size:11px;background:#e0e7ff;color:#3730a3;padding:2px 6px;border-radius:4px;margin-left:4px;">Anda</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($item->email); ?></td>
                        <td>
                            <?php echo e($item->anggota->nama ?? '-'); ?>

                        </td>
                        <td>
                            <?php $__empty_2 = true; $__currentLoopData = $item->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <?php if($r->name === 'admin'): ?>
                                    <span style="display:inline-block;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:600;background:#fee2e2;color:#b91c1c;">
                                        Admin
                                    </span>
                                <?php elseif($r->name === 'petugas'): ?>
                                    <span style="display:inline-block;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:600;background:#fef3c7;color:#b45309;">
                                        Petugas
                                    </span>
                                <?php else: ?>
                                    <span style="display:inline-block;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:600;background:#dbeafe;color:#1e40af;">
                                        <?php echo e(ucfirst($r->name)); ?>

                                    </span>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <span class="text-muted">Tanpa Role</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola role pengguna')): ?>
                                <form action="<?php echo e(route('users.updateRole', $item->id)); ?>" method="POST" style="display:flex;gap:6px;align-items:center;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>

                                    <select name="role" class="form-control" style="padding:6px 10px;font-size:13px;border-radius:6px;border:1px solid #cbd5e1;background:white;" required>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roleOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($roleOption->name); ?>" <?php echo e($item->hasRole($roleOption->name) ? 'selected' : ''); ?>>
                                                <?php echo e(ucfirst($roleOption->name)); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <button type="submit"
                                        style="background:#2563eb;color:white;border:none;padding:6px 12px;border-radius:6px;cursor:pointer;font-size:12px;white-space:nowrap;">
                                        Simpan
                                    </button>
                                </form>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('kelola data pengguna')): ?>
                                <?php if($item->id !== auth()->id()): ?>
                                    <form action="<?php echo e(route('users.destroy', $item->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus pengguna <?php echo e($item->name); ?>?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                            style="background:#dc2626;color:white;border:none;padding:6px 12px;border-radius:6px;cursor:pointer;font-size:12px;">
                                            Hapus
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center py-5">
                            <div style="font-size: 45px;">👥</div>
                            <h5 class="mt-3">Belum Ada Pengguna</h5>
                            <p class="text-muted">Belum ada data pengguna yang terdaftar.</p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <br>

    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">
        Kembali ke Dashboard
    </a>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\perpustakaan_250441100066\resources\views/users/index.blade.php ENDPATH**/ ?>