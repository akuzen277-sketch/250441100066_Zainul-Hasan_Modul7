

<?php $__env->startSection('title', 'Ajukan Peminjaman'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <h1>Ajukan Peminjaman 📚</h1>
    <p>Silakan pilih buku yang ingin kamu pinjam dari perpustakaan.</p>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">📖</div>
        <p>Menu</p>
        <h2>Pilih Buku</h2>
    </div>

    <div class="stat-card">
        <div class="stat-icon">⏳</div>
        <p>Status Awal</p>
        <h2>Menunggu</h2>
    </div>
</div>

<div class="content-card">
    <h3>Formulir Peminjaman Buku</h3>
    <p>Lengkapi formulir berikut untuk mengajukan peminjaman.</p>

    <br>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Pengajuan belum berhasil.</strong>
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('peminjaman.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-4">
            <label for="buku_id" class="form-label fw-semibold">
                Pilih Buku
            </label>

            <select name="buku_id" id="buku_id"
                    class="form-select" required>
                <option value="">-- Pilih Buku --</option>

                <?php $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($buku->id); ?>"
                        <?php echo e(old('buku_id') == $buku->id ? 'selected' : ''); ?>>
                        <?php echo e($buku->judul); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="alert alert-info">
            <strong>Informasi:</strong>
            Pengajuan peminjaman akan berstatus menunggu sampai Admin atau Petugas memprosesnya.
        </div>
        <br>
        <div class="d-flex flex-wrap gap-2">
            <button type="submit" class="btn-primary">
                Ajukan Peminjaman →
            </button>

            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">
                Kembali ke Dashboard
            </a>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\perpustakaan_250441100066\resources\views/peminjaman/create.blade.php ENDPATH**/ ?>