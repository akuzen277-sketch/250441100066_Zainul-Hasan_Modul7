<?php $__env->startSection('title', 'Laporan Perpustakaan'); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading">
    <h1>Laporan Perpustakaan 📊</h1>
    <p>Rekap data buku, kategori, dan aktivitas peminjaman di sistem perpustakaan.</p>
</div>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-icon">📚</div>
        <p>Total Buku</p>
        <h2><?php echo e($totalBuku); ?></h2>
    </div>

    <div class="stat-card">
        <div class="stat-icon">🏷️</div>
        <p>Total Kategori</p>
        <h2><?php echo e($totalKategori); ?></h2>
    </div>

    <div class="stat-card">
        <div class="stat-icon">📋</div>
        <p>Total Peminjaman</p>
        <h2><?php echo e($totalPeminjaman); ?></h2>
    </div>

    <div class="stat-card">
        <div class="stat-icon">✅</div>
        <p>Sedang Dipinjam</p>
        <h2><?php echo e($peminjamanDisetujui); ?></h2>
    </div>
</div>

<div class="content-card mb-4">
    <h3>Ringkasan Status Peminjaman Buku</h3>
    <p>Distribusi status peminjaman yang diajukan oleh siswa.</p>

    <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:16px;margin-top:16px;">
        <div style="background:#fef3c7;padding:16px;border-radius:10px;border-left:5px solid #d97706;">
            <p style="margin:0;color:#92400e;font-size:13px;font-weight:600;">⏳ Menunggu Persetujuan</p>
            <h3 style="margin:8px 0 0;color:#78350f;font-size:24px;"><?php echo e($peminjamanMenunggu); ?></h3>
        </div>

        <div style="background:#dcfce7;padding:16px;border-radius:10px;border-left:5px solid #16a34a;">
            <p style="margin:0;color:#166534;font-size:13px;font-weight:600;">✓ Disetujui (Sedang Dipinjam)</p>
            <h3 style="margin:8px 0 0;color:#14532d;font-size:24px;"><?php echo e($peminjamanDisetujui); ?></h3>
        </div>

        <div style="background:#fee2e2;padding:16px;border-radius:10px;border-left:5px solid #dc2626;">
            <p style="margin:0;color:#991b1b;font-size:13px;font-weight:600;">✕ Ditolak</p>
            <h3 style="margin:8px 0 0;color:#7f1d1d;font-size:24px;"><?php echo e($peminjamanDitolak); ?></h3>
        </div>

        <div style="background:#e0f2fe;padding:16px;border-radius:10px;border-left:5px solid #0284c7;">
            <p style="margin:0;color:#075985;font-size:13px;font-weight:600;">✔ Dikembalikan</p>
            <h3 style="margin:8px 0 0;color:#0c4a6e;font-size:24px;"><?php echo e($peminjamanDikembalikan); ?></h3>
        </div>
    </div>
</div>

<div class="content-card mb-4">
    <h3>Rekap Buku per Kategori</h3>
    <p>Jumlah koleksi buku yang terdaftar berdasarkan kategorinya.</p>

    <div class="table-responsive">
        <table class="table table-peminjaman align-middle">
            <thead>
                <tr>
                    <th style="width:70px;">NO</th>
                    <th>NAMA KATEGORI</th>
                    <th style="width:200px;">JUMLAH BUKU</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $bukuPerKategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><strong><?php echo e($kat->nama_kategori); ?></strong></td>
                        <td>
                            <span style="display:inline-block;padding:4px 12px;border-radius:20px;font-size:13px;font-weight:600;background:#e0e7ff;color:#3730a3;">
                                <?php echo e($kat->bukus_count); ?> Buku
                            </span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3" class="text-center py-4 text-muted">Belum ada data kategori.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="content-card mb-4">
    <h3>Buku Paling Sering Dipinjam</h3>
    <p>Top 10 buku dengan riwayat peminjaman terbanyak.</p>

    <div class="table-responsive">
        <table class="table table-peminjaman align-middle">
            <thead>
                <tr>
                    <th style="width:70px;">NO</th>
                    <th>JUDUL BUKU</th>
                    <th>PENULIS</th>
                    <th style="width:200px;">TOTAL DIPINJAM</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $peminjamanPerBuku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><strong><?php echo e($buku->judul); ?></strong></td>
                        <td><?php echo e($buku->penulis); ?></td>
                        <td>
                            <span style="display:inline-block;padding:4px 12px;border-radius:20px;font-size:13px;font-weight:600;background:#fef3c7;color:#b45309;">
                                <?php echo e($buku->peminjamans_count); ?> Kali
                            </span>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center py-4 text-muted">Belum ada riwayat peminjaman buku.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="content-card mb-4">
    <h3>Aktivitas Peminjaman Terbaru</h3>
    <p>Daftar 10 riwayat transaksi peminjaman buku terkini.</p>

    <div class="table-responsive">
        <table class="table table-peminjaman align-middle">
            <thead>
                <tr>
                    <th>NO</th>
                    <th>PEMINJAM</th>
                    <th>BUKU</th>
                    <th>TGL PINJAM</th>
                    <th>TGL KEMBALI</th>
                    <th>STATUS</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $peminjamanTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($p->anggota->nama ?? '-'); ?></td>
                        <td><strong><?php echo e($p->buku->judul ?? '-'); ?></strong></td>
                        <td><?php echo e(\Carbon\Carbon::parse($p->tanggal_pinjam)->format('d M Y')); ?></td>
                        <td>
                            <?php if($p->tanggal_kembali): ?>
                                <?php echo e(\Carbon\Carbon::parse($p->tanggal_kembali)->format('d M Y')); ?>

                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($p->status === 'disetujui'): ?>
                                <span style="display:inline-block;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:600;background:#dcfce7;color:#15803d;">
                                    ✓ Disetujui
                                </span>
                            <?php elseif($p->status === 'ditolak'): ?>
                                <span style="display:inline-block;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:600;background:#fee2e2;color:#b91c1c;">
                                    ✕ Ditolak
                                </span>
                            <?php elseif($p->status === 'dikembalikan'): ?>
                                <span style="display:inline-block;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:600;background:#e0f2fe;color:#0369a1;">
                                    ✔ Dikembalikan
                                </span>
                            <?php else: ?>
                                <span style="display:inline-block;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:600;background:#fef3c7;color:#b45309;">
                                    ⏳ Menunggu
                                </span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4 text-muted">Belum ada transaksi peminjaman.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <br>

    <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-secondary">
        Kembali ke Dashboard
    </a>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\perpustakaan_250441100066\resources\views/laporan/index.blade.php ENDPATH**/ ?>