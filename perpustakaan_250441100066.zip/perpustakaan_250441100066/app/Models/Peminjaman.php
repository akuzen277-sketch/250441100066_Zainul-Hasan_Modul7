<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Peminjaman extends Model
{
    use HasFactory;

    protected $table = 'peminjamans';

    protected $fillable = [
        'anggota_id',
        'buku_id',
        'tanggal_pinjam',
        'tanggal_kembali',
        'status',
    ];

    // Relasi ke tabel anggota
    public function anggota(): BelongsTo
    {
        return $this->belongsTo(Anggota::class);
    }

    // Relasi ke tabel buku
    public function buku(): BelongsTo
    {
        return $this->belongsTo(Buku::class);
    }
}
